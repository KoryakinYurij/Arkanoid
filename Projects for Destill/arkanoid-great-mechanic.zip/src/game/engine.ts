import { BASE_KINDS, FUSION_KINDS, KINDS, PASSIVES, effectsOf } from "./data";
import type { Card, HitEffects, Kind } from "./data";
import { Sfx } from "./audio";

export const W = 540;
export const H = 960;
const PLAY_TOP = 104;
const PADDLE_Y = 872;
const PADDLE_H = 14;
const COLS = 9;
const CW = 56;
const MARGIN = (W - COLS * CW) / 2;
const ROW_H = 34;
const GAP = 3;
const DANGER_Y = 806;
const NET_Y = 930;
const BALL_R = 7;
const BALL_SPEED = 540;
const BOSS_EVERY = 14;
const MAX_BALLS = 32;
const FONT = "'Russo One','Trebuchet MS','Segoe UI',system-ui,sans-serif";

export type Screen = "menu" | "playing" | "paused" | "levelup" | "gameover";

export interface Summary {
  score: number;
  depth: number;
  level: number;
  kills: number;
  maxCombo: number;
  perfects: number;
}

export interface Loadout {
  balls: { kind: Kind; count: number; level: number }[];
  passives: { id: string; name: string; icon: string; lvl: number }[];
}

export interface GameCallbacks {
  onScreen(s: Screen): void;
  onCards(cards: Card[]): void;
  onGameOver(r: Summary): void;
}

interface Brick {
  id: number;
  x: number;
  y: number;
  w: number;
  h: number;
  hp: number;
  maxhp: number;
  type: "n" | "a" | "x" | "g" | "boss";
  flash: number;
  pop: number;
  burn: number;
  burnDps: number;
  poison: number;
  pStacks: number;
  pDps: number;
  frozen: number;
  toxic: boolean;
  dead: boolean;
  tick: number;
}

interface Ball {
  x: number;
  y: number;
  vx: number;
  vy: number;
  kind: Kind;
  mom: number;
  charged: boolean;
  pierceLeft: number;
  ignore: Brick[];
  trail: { x: number; y: number }[];
  dead: boolean;
}

interface Orb {
  x: number;
  y: number;
  vx: number;
  vy: number;
  v: number;
  heart: boolean;
  t: number;
}

interface Part {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  size: number;
  color: string;
  kind: 0 | 1 | 2 | 3;
  g: number;
}

interface FText {
  x: number;
  y: number;
  text: string;
  life: number;
  max: number;
  color: string;
  size: number;
}

interface Bolt {
  pts: number[];
  life: number;
  max: number;
  color: string;
}

type Pal = { body: string; top: string; dark: string; glow: string };

const HUES = [165, 180, 195, 210, 230, 255, 275, 295, 315, 335, 355, 12, 28, 42, 52, 75];
const PAL: Pal[] = HUES.map((h) => ({
  body: `hsl(${h} 80% 52%)`,
  top: `hsl(${h} 95% 72%)`,
  dark: `hsl(${h} 70% 28%)`,
  glow: `hsl(${h} 100% 62%)`,
}));
const PAL_ARMOR: Pal = { body: "#7b86a6", top: "#cfd6ea", dark: "#434b68", glow: "#aab6e0" };
const PAL_TNT: Pal = { body: "#e0382f", top: "#ff9370", dark: "#7e1a1a", glow: "#ff5a3c" };
const PAL_GEM: Pal = { body: "#2fd8cc", top: "#c4fffb", dark: "#12766f", glow: "#4dfff1" };
const PAL_BOSS: Pal = { body: "#4a1664", top: "#ff58ee", dark: "#1c0830", glow: "#ff3df0" };

function tierOf(hp: number) {
  const h = Math.max(1, Math.ceil(hp));
  if (h <= 10) return h - 1;
  return Math.min(15, 9 + Math.ceil((h - 10) / 6));
}

const UPGRADE_TEXT: Record<Kind, string> = {
  normal: "",
  fire: "Горение жжёт сильнее.",
  ice: "Заморозка длится дольше.",
  bolt: "+1 цель цепи, дальше дуга.",
  bomb: "Шире радиус и сильнее взрыв.",
  poison: "Яд бьёт сильнее.",
  drill: "+1 пробитие кирпичей.",
  nova: "Больше радиус и жар взрыва.",
  storm: "+1 дуга и дольше заморозка.",
  plague: "Токсичное пламя злее.",
  rail: "+1 пробитие и больше дуг.",
};

const glowCache = new Map<string, HTMLCanvasElement>();
function glowSprite(color: string): HTMLCanvasElement {
  let c = glowCache.get(color);
  if (c) return c;
  c = document.createElement("canvas");
  c.width = c.height = 64;
  const g = c.getContext("2d")!;
  const grd = g.createRadialGradient(32, 32, 0, 32, 32, 32);
  grd.addColorStop(0, color);
  grd.addColorStop(0.35, color);
  grd.addColorStop(1, "rgba(0,0,0,0)");
  g.globalAlpha = 0.85;
  g.fillStyle = grd;
  g.fillRect(0, 0, 64, 64);
  glowCache.set(color, c);
  return c;
}

function rr(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath();
  if (typeof ctx.roundRect === "function") ctx.roundRect(x, y, w, h, r);
  else ctx.rect(x, y, w, h);
}

const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
const rand = (a: number, b: number) => a + Math.random() * (b - a);

export class Game {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  readonly sfx = new Sfx();
  private cb: GameCallbacks;
  private raf = 0;
  private last = 0;
  private time = 0;
  private scale = 1;
  private bg: HTMLCanvasElement | null = null;

  screen: Screen = "menu";
  private demo = true;

  // world
  private bricks: Brick[] = [];
  private balls: Ball[] = [];
  private orbs: Orb[] = [];
  private parts: Part[] = [];
  private texts: FText[] = [];
  private bolts: Bolt[] = [];
  private timers: { t: number; fn: () => void }[] = [];
  private brickId = 1;

  // player
  private px = W / 2;
  private ptarget = W / 2;
  private pvx = 0;
  private kv = 0;
  private padPop = 0;
  private score = 0;
  private shownScore = 0;
  private hp = 3;
  private maxHp = 3;
  private xp = 0;
  private xpShown = 0;
  private xpNeed = 4;
  private level = 1;
  private pending = 0;
  private arsenal = {} as Record<Kind, { count: number; level: number }>;
  private passives: Record<string, number> = {};
  private combo = 0;
  private comboT = 0;
  private comboPop = 0;
  private maxCombo = 0;
  private kills = 0;
  private perfects = 0;
  private warp = 50;
  private warpHeld = false;
  private timeScale = 1;
  private orbChain = 0;
  private orbChainT = 0;

  // volley
  private phase: "ready" | "firing" | "flying" = "ready";
  private readyT = 0.3;
  private readyMax = 0.3;
  private queue: Kind[] = [];
  private launchT = 0;
  private launchIdx = 0;
  private volleySize = 0;
  private lowT = 0;
  private net = 0;

  // field
  private rowIndex = 0;
  private accum = 0;
  private skipCenter = 0;
  private gridOff = 0;
  private danger = 0;

  // fx
  private shake = 0;
  private hitstop = 0;
  private flashA = 0;
  private flashColor = "#fff";
  private bannerT = 0;
  private bannerText = "";
  private bannerSub = "";
  private bannerColor = "#fff";
  private choices: Card[] = [];

  // input
  private keys = new Set<string>();
  private movePtr = -1;
  private warpPtr = -1;
  private lastPX = 0;
  private cleanup: (() => void)[] = [];

  constructor(canvas: HTMLCanvasElement, cb: GameCallbacks) {
    this.canvas = canvas;
    this.ctx = canvas.getContext("2d", { alpha: false })!;
    this.cb = cb;
    this.reset(true);
    this.bindInput();
    this.raf = requestAnimationFrame(this.loop);
  }

  destroy() {
    cancelAnimationFrame(this.raf);
    this.cleanup.forEach((f) => f());
  }

  /* ───────────────────────── public API ───────────────────────── */

  setSize(cssW: number, dpr: number) {
    this.canvas.width = Math.round(cssW * dpr);
    this.canvas.height = Math.round((cssW * H * dpr) / W);
    this.scale = this.canvas.width / W;
    this.buildBg();
  }

  start() {
    this.sfx.init();
    this.sfx.play("select");
    this.reset(false);
    this.setScreen("playing");
  }

  restart() {
    this.start();
  }

  toMenu() {
    this.reset(true);
    this.setScreen("menu");
  }

  pause() {
    if (this.screen !== "playing") return;
    this.warpHeld = false;
    this.setScreen("paused");
  }

  resume() {
    if (this.screen !== "paused") return;
    this.setScreen("playing");
  }

  setMuted(m: boolean) {
    this.sfx.setMuted(m);
  }

  pick(id: string) {
    if (this.screen !== "levelup") return;
    this.sfx.play("select");
    this.applyCard(id);
    this.setScreen("playing");
    if (this.pending > 0) this.openLevelUp();
  }

  getLoadout(): Loadout {
    const balls = (Object.keys(this.arsenal) as Kind[])
      .filter((k) => this.arsenal[k].count > 0)
      .map((k) => ({ kind: k, count: this.arsenal[k].count, level: this.arsenal[k].level }));
    const passives = PASSIVES.filter((p) => (this.passives[p.id] || 0) > 0).map((p) => ({
      id: p.id,
      name: p.name,
      icon: p.icon,
      lvl: this.passives[p.id],
    }));
    return { balls, passives };
  }

  /* ───────────────────────── setup ───────────────────────── */

  private setScreen(s: Screen) {
    this.screen = s;
    this.cb.onScreen(s);
  }

  private reset(demo: boolean) {
    this.demo = demo;
    this.bricks = [];
    this.balls = [];
    this.orbs = [];
    this.parts = [];
    this.texts = [];
    this.bolts = [];
    this.timers = [];
    this.score = 0;
    this.shownScore = 0;
    this.hp = 3;
    this.maxHp = 3;
    this.xp = 0;
    this.xpShown = 0;
    this.level = 1;
    this.xpNeed = this.needFor(1);
    this.pending = 0;
    const ars = {} as Record<Kind, { count: number; level: number }>;
    (Object.keys(KINDS) as Kind[]).forEach((k) => (ars[k] = { count: 0, level: 0 }));
    ars.normal = { count: 5, level: 1 };
    if (demo) {
      ars.fire = { count: 1, level: 3 };
      ars.bolt = { count: 1, level: 3 };
      ars.bomb = { count: 1, level: 2 };
      ars.drill = { count: 1, level: 2 };
      ars.storm = { count: 1, level: 2 };
    }
    this.arsenal = ars;
    this.passives = {};
    this.combo = 0;
    this.comboT = 0;
    this.maxCombo = 0;
    this.kills = 0;
    this.perfects = 0;
    this.warp = 50;
    this.warpHeld = false;
    this.timeScale = 1;
    this.phase = "ready";
    this.readyT = 0.35;
    this.readyMax = 0.35;
    this.queue = [];
    this.net = 0;
    this.rowIndex = 0;
    this.accum = ROW_H * 0.9;
    this.skipCenter = 0;
    this.shake = 0;
    this.hitstop = 0;
    this.flashA = 0;
    this.bannerT = 0;
    this.px = this.ptarget = W / 2;
    this.pvx = 0;
    this.kv = 0;
    for (let k = 6; k >= 0; k--) this.spawnRow(PLAY_TOP - ROW_H + this.accum + k * ROW_H);
  }

  private needFor(lvl: number) {
    return Math.floor(3 + (lvl - 1) * 2.2 + (lvl - 1) * (lvl - 1) * 0.14);
  }

  private pw() {
    return 110 * (1 + 0.14 * (this.passives.wide || 0));
  }

  private buildBg() {
    const c = document.createElement("canvas");
    c.width = this.canvas.width;
    c.height = this.canvas.height;
    const g = c.getContext("2d")!;
    g.scale(this.scale, this.scale);
    const grd = g.createLinearGradient(0, 0, 0, H);
    grd.addColorStop(0, "#0c0420");
    grd.addColorStop(0.5, "#120733");
    grd.addColorStop(1, "#1d0a3d");
    g.fillStyle = grd;
    g.fillRect(0, 0, W, H);
    // glow in the center
    const rg = g.createRadialGradient(W / 2, 520, 20, W / 2, 520, 560);
    rg.addColorStop(0, "rgba(120,60,255,0.28)");
    rg.addColorStop(1, "rgba(120,60,255,0)");
    g.fillStyle = rg;
    g.fillRect(0, 0, W, H);
    // vertical lanes
    g.strokeStyle = "rgba(140,110,255,0.07)";
    g.lineWidth = 1;
    for (let i = 0; i <= COLS; i++) {
      g.beginPath();
      g.moveTo(MARGIN + i * CW, PLAY_TOP);
      g.lineTo(MARGIN + i * CW, H);
      g.stroke();
    }
    // walls
    const wl = g.createLinearGradient(0, 0, 14, 0);
    wl.addColorStop(0, "rgba(255,70,220,0.55)");
    wl.addColorStop(1, "rgba(255,70,220,0)");
    g.fillStyle = wl;
    g.fillRect(0, PLAY_TOP, 14, H - PLAY_TOP);
    const wr = g.createLinearGradient(W, 0, W - 14, 0);
    wr.addColorStop(0, "rgba(60,230,255,0.55)");
    wr.addColorStop(1, "rgba(60,230,255,0)");
    g.fillStyle = wr;
    g.fillRect(W - 14, PLAY_TOP, 14, H - PLAY_TOP);
    // HUD panel
    const hp = g.createLinearGradient(0, 0, 0, PLAY_TOP);
    hp.addColorStop(0, "#07021a");
    hp.addColorStop(1, "#150a33");
    g.fillStyle = hp;
    g.fillRect(0, 0, W, PLAY_TOP);
    g.fillStyle = "rgba(255,80,230,0.9)";
    g.fillRect(0, PLAY_TOP - 2, W / 2, 2);
    g.fillStyle = "rgba(60,230,255,0.9)";
    g.fillRect(W / 2, PLAY_TOP - 2, W / 2, 2);
    this.bg = c;
  }

  /* ───────────────────────── input ───────────────────────── */

  private toWorld(e: PointerEvent) {
    const r = this.canvas.getBoundingClientRect();
    return { x: ((e.clientX - r.left) / r.width) * W, y: ((e.clientY - r.top) / r.height) * H };
  }

  private requestLaunch(manual = true) {
    if (this.phase === "ready") this.readyT = 0;
    else if (manual && this.phase === "flying" && this.balls.length <= Math.max(1, Math.ceil(this.volleySize * 0.5))) this.recall();
  }

  /** Dissolve the remaining balls and immediately prepare the next volley. */
  private recall() {
    for (const b of this.balls) {
      this.spark(b.x, b.y, KINDS[b.kind].color, 6, 200, 0.4);
      this.ring(b.x, b.y, KINDS[b.kind].color, 24, 0.3);
    }
    if (this.balls.length) this.text(this.px, PADDLE_Y - 60, "ВОЗВРАТ ШАРОВ", "#9bd8ff", 16, 0.8);
    this.balls = [];
    this.phase = "ready";
    this.readyT = this.readyMax = 0.25;
    this.lowT = 0;
  }

  private bindInput() {
    const cv = this.canvas;
    const down = (e: PointerEvent) => {
      this.sfx.init();
      if (this.screen !== "playing") return;
      const p = this.toWorld(e);
      if (Math.hypot(p.x - 500, p.y - 36) < 28) {
        this.pause();
        return;
      }
      if (Math.hypot(p.x - 486, p.y - 922) < 38) {
        this.warpPtr = e.pointerId;
        this.warpHeld = true;
        cv.setPointerCapture?.(e.pointerId);
        return;
      }
      if (this.movePtr === -1) {
        this.movePtr = e.pointerId;
        this.lastPX = p.x;
        if (e.pointerType === "mouse") this.ptarget = p.x;
        cv.setPointerCapture?.(e.pointerId);
      }
      this.requestLaunch(e.pointerType === "mouse");
    };
    const move = (e: PointerEvent) => {
      if (this.screen !== "playing") return;
      const p = this.toWorld(e);
      if (e.pointerType === "mouse") {
        this.ptarget = p.x;
      } else if (e.pointerId === this.movePtr) {
        this.ptarget += (p.x - this.lastPX) * 1.5;
        this.lastPX = p.x;
      }
    };
    const up = (e: PointerEvent) => {
      if (e.pointerId === this.movePtr) this.movePtr = -1;
      if (e.pointerId === this.warpPtr) {
        this.warpPtr = -1;
        this.warpHeld = false;
      }
    };
    cv.addEventListener("pointerdown", down);
    cv.addEventListener("pointermove", move);
    cv.addEventListener("pointerup", up);
    cv.addEventListener("pointercancel", up);
    cv.addEventListener("contextmenu", (e) => e.preventDefault());

    const kd = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement | null;
      if (t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA")) return;
      const c = e.code;
      this.sfx.init();
      if (c === "ArrowLeft" || c === "ArrowRight" || c === "Space" || c === "ArrowUp" || c === "ArrowDown") e.preventDefault();
      if (e.repeat && c !== "ArrowLeft" && c !== "ArrowRight") return;
      this.keys.add(c);
      switch (this.screen) {
        case "menu":
          if (c === "Enter" || c === "Space") this.start();
          break;
        case "gameover":
          if (c === "Enter" || c === "Space" || c === "KeyR") this.start();
          break;
        case "levelup": {
          const i = c === "Digit1" || c === "Numpad1" ? 0 : c === "Digit2" || c === "Numpad2" ? 1 : c === "Digit3" || c === "Numpad3" ? 2 : -1;
          if (i >= 0 && this.choices[i]) this.pick(this.choices[i].id);
          break;
        }
        case "paused":
          if (c === "Escape" || c === "KeyP" || c === "Space" || c === "Enter") this.resume();
          else if (c === "KeyR") this.start();
          break;
        case "playing":
          if (c === "Space" || c === "Enter") this.requestLaunch();
          else if (c === "Escape" || c === "KeyP") this.pause();
          else if (c === "KeyR") this.start();
          break;
      }
      if (c === "KeyM") {
        this.sfx.setMuted(!this.sfx.muted);
      }
    };
    const ku = (e: KeyboardEvent) => this.keys.delete(e.code);
    const vis = () => {
      if (document.hidden) this.pause();
    };
    const blur = () => {
      this.keys.clear();
      this.pause();
    };
    window.addEventListener("keydown", kd);
    window.addEventListener("keyup", ku);
    window.addEventListener("blur", blur);
    document.addEventListener("visibilitychange", vis);
    this.cleanup.push(() => {
      cv.removeEventListener("pointerdown", down);
      cv.removeEventListener("pointermove", move);
      cv.removeEventListener("pointerup", up);
      cv.removeEventListener("pointercancel", up);
      window.removeEventListener("keydown", kd);
      window.removeEventListener("keyup", ku);
      window.removeEventListener("blur", blur);
      document.removeEventListener("visibilitychange", vis);
    });
  }

  /* ───────────────────────── main loop ───────────────────────── */

  private loop = (now: number) => {
    this.raf = requestAnimationFrame(this.loop);
    let rdt = (now - this.last) / 1000;
    this.last = now;
    if (!(rdt > 0)) rdt = 1 / 60;
    rdt = Math.min(rdt, 0.05);
    this.time += rdt;
    this.update(rdt);
    this.render();
  };

  private update(rdt: number) {
    // cosmetic things always
    this.shake *= Math.exp(-rdt * 9);
    if (this.shake < 0.05) this.shake = 0;
    this.flashA = Math.max(0, this.flashA - rdt * 2.2);
    this.shownScore += (this.score - this.shownScore) * Math.min(1, rdt * 10);
    if (Math.abs(this.score - this.shownScore) < 1) this.shownScore = this.score;
    this.xpShown += (this.xp / this.xpNeed - this.xpShown) * Math.min(1, rdt * 10);
    this.comboPop = Math.max(0, this.comboPop - rdt * 4);
    this.padPop = Math.max(0, this.padPop - rdt * 6);
    if (this.bannerT > 0) this.bannerT -= rdt;

    if (this.screen === "playing" || this.screen === "menu") {
      let dt = rdt;
      if (this.hitstop > 0) {
        this.hitstop -= rdt;
        dt = 0;
      } else {
        // time warp
        const maxW = this.maxWarp();
        const want = this.screen === "playing" && (this.warpHeld || this.keys.has("ShiftLeft") || this.keys.has("ShiftRight") || this.keys.has("KeyW") || this.keys.has("ArrowUp")) && this.warp > 0;
        const target = want ? 0.3 : 1;
        this.timeScale += (target - this.timeScale) * Math.min(1, rdt * 10);
        if (want) this.warp = Math.max(0, this.warp - rdt * 34 * (1 - 0.18 * (this.passives.chrono || 0)));
        this.warp = Math.min(maxW, this.warp);
        dt = rdt * this.timeScale;
      }
      this.sim(dt, rdt);
    } else if (this.screen === "gameover") {
      this.updateTimers(rdt);
      this.updateParticles(rdt);
      this.updateTexts(rdt);
      this.bolts = this.bolts.filter((b) => (b.life -= rdt) > 0);
    }
  }

  private maxWarp() {
    return 100;
  }

  private after(t: number, fn: () => void) {
    this.timers.push({ t, fn });
  }

  private updateTimers(dt: number) {
    for (let i = this.timers.length - 1; i >= 0; i--) {
      const tm = this.timers[i];
      tm.t -= dt;
      if (tm.t <= 0) {
        this.timers.splice(i, 1);
        tm.fn();
      }
    }
  }

  private sim(dt: number, rdt: number) {
    this.updatePaddle(rdt);
    this.updateVolley(dt);
    this.updateBalls(dt);
    this.updateBricks(dt);
    this.updateOrbs(dt);
    this.updateTimers(dt);
    this.updateParticles(dt);
    this.updateTexts(dt);
    this.bolts = this.bolts.filter((b) => (b.life -= dt) > 0);

    if (this.comboT > 0) {
      this.comboT -= dt;
      if (this.comboT <= 0) this.combo = 0;
    }
    if (this.orbChainT > 0) {
      this.orbChainT -= dt;
      if (this.orbChainT <= 0) this.orbChain = 0;
    }

    // level up check
    if (!this.demo && this.screen === "playing") {
      while (this.xp >= this.xpNeed) {
        this.xp -= this.xpNeed;
        this.level++;
        this.pending++;
        this.xpNeed = this.needFor(this.level);
      }
      if (this.pending > 0) this.openLevelUp();
    }
  }

  /* ───────────────────────── paddle & volley ───────────────────────── */

  private updatePaddle(rdt: number) {
    const pw = this.pw();
    if (this.demo) {
      // autopilot
      let best: Ball | null = null;
      for (const b of this.balls) if (b.vy > 0 && (!best || b.y > best.y)) best = b;
      this.ptarget = best ? best.x + Math.sin(this.time * 1.7) * pw * 0.28 : W / 2 + Math.sin(this.time) * 120;
    } else {
      const l = this.keys.has("ArrowLeft") || this.keys.has("KeyA");
      const r = this.keys.has("ArrowRight") || this.keys.has("KeyD");
      const dir = (r ? 1 : 0) - (l ? 1 : 0);
      this.kv += (dir * 950 - this.kv) * Math.min(1, rdt * 16);
      if (Math.abs(this.kv) > 1) this.ptarget += this.kv * rdt;
    }
    this.ptarget = clamp(this.ptarget, pw / 2, W - pw / 2);
    const prev = this.px;
    this.px += (this.ptarget - this.px) * (1 - Math.exp(-rdt * (this.demo ? 12 : 38)));
    this.pvx += ((this.px - prev) / Math.max(rdt, 0.001) - this.pvx) * Math.min(1, rdt * 20);
  }

  private buildQueue(): Kind[] {
    const q: Kind[] = [];
    (Object.keys(this.arsenal) as Kind[]).forEach((k) => {
      for (let i = 0; i < this.arsenal[k].count; i++) q.push(k);
    });
    // light shuffle so that effects are mixed
    for (let i = q.length - 1; i > 0; i--) {
      if (Math.random() < 0.6) {
        const j = Math.floor(Math.random() * (i + 1));
        [q[i], q[j]] = [q[j], q[i]];
      }
    }
    return q.slice(0, MAX_BALLS);
  }

  private spawnBall(kind: Kind) {
    const a = -Math.PI / 2 + rand(-0.2, 0.2) + clamp(this.pvx / 3500, -0.3, 0.3);
    const fx = effectsOf(kind, this.arsenal[kind].level);
    this.balls.push({
      x: this.px + rand(-8, 8),
      y: PADDLE_Y - 12,
      vx: Math.cos(a) * BALL_SPEED,
      vy: Math.sin(a) * BALL_SPEED,
      kind,
      mom: 0,
      charged: false,
      pierceLeft: fx.pierce || 0,
      ignore: [],
      trail: [],
      dead: false,
    });
  }

  /** Deploy freshly acquired balls right away if a volley is in progress. */
  private deploy(kind: Kind, n: number) {
    if (this.phase === "ready" || this.screen === "gameover") return;
    for (let i = 0; i < n; i++) {
      this.after(0.12 + i * 0.1, () => {
        if (this.phase === "ready") return;
        this.spawnBall(kind);
        this.volleySize++;
        this.spark(this.px, PADDLE_Y - 8, KINDS[kind].color, 6, 220, 0.4);
        this.sfx.play("launch", 8);
      });
    }
  }

  private updateVolley(dt: number) {
    if (this.phase === "ready") {
      this.readyT -= dt;
      if (this.readyT <= 0) {
        this.queue = this.buildQueue();
        this.volleySize = this.queue.length;
        this.lowT = 0;
        this.launchIdx = 0;
        this.launchT = 0;
        this.phase = "firing";
        this.net = (this.passives.net || 0) * 2;
      }
    }
    if (this.phase === "firing") {
      const interval = Math.min(0.075, 1.2 / Math.max(1, this.queue.length + this.launchIdx));
      this.launchT -= dt;
      while (this.launchT <= 0 && this.queue.length) {
        this.launchT += interval;
        const kind = this.queue.shift()!;
        this.spawnBall(kind);
        this.launchIdx++;
        this.sfx.play("launch", this.launchIdx);
        this.spark(this.px, PADDLE_Y - 8, KINDS[kind].color, 3, 160, 0.3);
      }
      if (!this.queue.length) this.phase = "flying";
    }
    if (this.phase === "flying") {
      if (this.balls.length === 0) {
        this.phase = "ready";
        this.readyT = this.readyMax = 0.55;
      } else if (this.balls.length <= Math.max(1, Math.floor(this.volleySize * 0.25))) {
        this.lowT += dt;
        if (this.lowT > 3) this.recall();
      } else {
        this.lowT = 0;
      }
    }
  }

  /* ───────────────────────── balls ───────────────────────── */

  private updateBalls(dt: number) {
    const pw = this.pw();
    const R = BALL_R;
    const perfectWin = 0.15 + 0.06 * (this.passives.parry || 0);
    for (const b of this.balls) {
      const dist = BALL_SPEED * dt;
      const steps = Math.max(1, Math.ceil(dist / 4.5));
      const h = dt / steps;
      const L = this.arsenal[b.kind].level;
      const fx = effectsOf(b.kind, L);
      // trail
      let tr = b.trail.length >= 8 ? b.trail.pop()! : { x: 0, y: 0 };
      tr.x = b.x;
      tr.y = b.y;
      b.trail.unshift(tr);

      for (let s = 0; s < steps && !b.dead; s++) {
        b.x += b.vx * h;
        b.y += b.vy * h;

        // walls
        if (b.x < R) {
          b.x = R;
          b.vx = Math.abs(b.vx);
          this.wallBounce(b, fx);
        } else if (b.x > W - R) {
          b.x = W - R;
          b.vx = -Math.abs(b.vx);
          this.wallBounce(b, fx);
        }
        if (b.y < PLAY_TOP + R) {
          b.y = PLAY_TOP + R;
          b.vy = Math.abs(b.vy);
          this.wallBounce(b, fx);
        }

        // paddle
        if (b.vy > 0 && b.y + R >= PADDLE_Y && b.y - R <= PADDLE_Y + PADDLE_H && Math.abs(b.x - this.px) <= pw / 2 + R * 0.8) {
          const off = clamp((b.x - this.px) / (pw / 2), -1, 1);
          const a = clamp(off * 1.05 + this.pvx / 2600, -1.2, 1.2);
          b.vx = Math.sin(a) * BALL_SPEED;
          b.vy = -Math.cos(a) * BALL_SPEED;
          b.y = PADDLE_Y - R - 0.5;
          b.pierceLeft = fx.pierce || 0;
          b.ignore.length = 0;
          this.padPop = 1;
          this.sfx.play("paddle");
          if (Math.abs(off) < perfectWin && !this.demo) {
            if (!b.charged) {
              b.charged = true;
              this.perfects++;
              this.warp = Math.min(this.maxWarp(), this.warp + 7);
              this.ring(b.x, PADDLE_Y, "#ffd84d", 60, 0.35);
              this.spark(b.x, PADDLE_Y, "#ffd84d", 12, 320, 0.4);
              this.text(b.x, PADDLE_Y - 30, "ИДЕАЛЬНО", "#ffd84d", 18, 0.7);
              this.sfx.play("perfect");
              this.shake += 1.5;
            }
          } else {
            this.spark(b.x, PADDLE_Y, "#7ff", 4, 160, 0.25);
          }
        }

        // net / lost
        if (b.y + R > NET_Y && b.vy > 0) {
          if (this.net > 0) {
            this.net--;
            b.vy = -Math.abs(b.vy);
            b.y = NET_Y - R;
            this.sfx.play("net");
            this.ring(b.x, NET_Y, "#6ff", 36, 0.3);
            this.spark(b.x, NET_Y, "#6ff", 10, 260, 0.4);
          } else if (b.y - R > H + 10) {
            b.dead = true;
            this.sfx.play("lost");
            this.spark(b.x, H - 20, KINDS[b.kind].color, 8, 200, 0.4);
          }
        }

        // ignore cleanup
        if (b.ignore.length) {
          b.ignore = b.ignore.filter((br) => !br.dead && this.overlaps(b, br));
        }

        // bricks
        for (let i = 0; i < this.bricks.length; i++) {
          const br = this.bricks[i];
          if (br.dead) continue;
          if (b.x + R < br.x || b.x - R > br.x + br.w || b.y + R < br.y || b.y - R > br.y + br.h) continue;
          if (br.y + br.h < PLAY_TOP) continue;
          const cx = clamp(b.x, br.x, br.x + br.w);
          const cy = clamp(b.y, br.y, br.y + br.h);
          const dx = b.x - cx;
          const dy = b.y - cy;
          const d2 = dx * dx + dy * dy;
          if (d2 > R * R) continue;
          if (b.ignore.includes(br)) continue;

          if (b.pierceLeft > 0) {
            b.pierceLeft--;
            b.ignore.push(br);
          } else {
            let nx = 0;
            let ny = 0;
            if (d2 < 0.0001) {
              const l = b.x - br.x;
              const r = br.x + br.w - b.x;
              const t = b.y - br.y;
              const bt = br.y + br.h - b.y;
              const m = Math.min(l, r, t, bt);
              if (m === l) nx = -1;
              else if (m === r) nx = 1;
              else if (m === t) ny = -1;
              else ny = 1;
              b.x += nx * (R + m);
              b.y += ny * (R + m);
            } else {
              const d = Math.sqrt(d2);
              nx = dx / d;
              ny = dy / d;
              b.x = cx + nx * (R + 0.4);
              b.y = cy + ny * (R + 0.4);
            }
            const dot = b.vx * nx + b.vy * ny;
            if (dot < 0) {
              b.vx -= 2 * dot * nx;
              b.vy -= 2 * dot * ny;
            }
            this.normalize(b);
            b.pierceLeft = fx.pierce || 0;
            b.ignore.length = 0;
          }
          this.hitBrick(b, br, fx);
          if (b.pierceLeft <= 0 || b.ignore.length === 0) break;
        }
      }
    }
    // remove dead
    if (this.balls.some((b) => b.dead)) this.balls = this.balls.filter((b) => !b.dead);
  }

  private overlaps(b: Ball, br: Brick) {
    const cx = clamp(b.x, br.x, br.x + br.w);
    const cy = clamp(b.y, br.y, br.y + br.h);
    const dx = b.x - cx;
    const dy = b.y - cy;
    return dx * dx + dy * dy <= (BALL_R + 1) * (BALL_R + 1);
  }

  private normalize(b: Ball) {
    const min = BALL_SPEED * 0.24;
    if (Math.abs(b.vy) < min) {
      b.vy = (b.vy < 0 || b.vy === 0 ? -1 : 1) * min;
    }
    const l = Math.hypot(b.vx, b.vy);
    b.vx = (b.vx / l) * BALL_SPEED;
    b.vy = (b.vy / l) * BALL_SPEED;
  }

  private wallBounce(b: Ball, fx: HitEffects) {
    this.normalize(b);
    b.mom++;
    b.pierceLeft = fx.pierce || 0;
    b.ignore.length = 0;
    this.spark(b.x, b.y, "#b9a6ff", 2, 100, 0.2);
  }

  /* ───────────────────────── hits & effects ───────────────────────── */

  private hitBrick(b: Ball, br: Brick, fx: HitEffects) {
    const color = KINDS[b.kind].color;
    let dmg = (1 + 0.25 * (this.passives.dmg || 0)) * fx.dmgMul;
    const ric = this.passives.ric || 0;
    if (ric && b.mom) dmg *= 1 + b.mom * 0.3 * ric;
    b.mom = 0;
    let crit = false;
    if (b.charged) {
      dmg *= 2 + 0.5 * (this.passives.parry || 0);
      b.charged = false;
      crit = true;
      this.ring(b.x, b.y, "#ffd84d", 50, 0.3);
      this.shake += 3;
    }
    if (Math.random() < 0.08 * (this.passives.crit || 0)) {
      dmg *= 2;
      crit = true;
    }
    if (br.frozen > 0) dmg *= 1.5;

    this.combo++;
    this.comboT = 2.4;
    this.comboPop = 1;
    if (this.combo > this.maxCombo) this.maxCombo = this.combo;
    this.sfx.play("hit", this.combo);
    this.shake += 0.6;
    this.spark(b.x, b.y, color, 4, 220, 0.3);

    this.hurt(br, dmg, crit);

    if (!br.dead) {
      if (fx.burn) this.ignite(br, fx.burn.dps, fx.burn.dur);
      if (fx.freeze) this.freeze(br, fx.freeze);
      if (fx.poison) this.poison(br, fx.poison.stacks, fx.poison.dps, 4, b.kind === "plague");
    }
    if (b.kind === "plague") br.toxic = true;
    if (fx.arcs) this.arc(br, fx.arcs, dmg, color);
    if (fx.boom) {
      this.explode(b.x, b.y, fx.boom.r, dmg * fx.boom.dmg, color, fx.boom.burn, br);
    }
  }

  private ignite(br: Brick, dps: number, dur: number) {
    if (br.dead) return;
    br.burn = Math.max(br.burn, dur);
    br.burnDps = Math.max(br.burnDps, dps);
  }

  private freeze(br: Brick, t: number) {
    if (br.dead) return;
    if (br.frozen <= 0) {
      this.sfx.play("ice");
      this.spark(br.x + br.w / 2, br.y + br.h / 2, "#bff6ff", 6, 140, 0.4);
    }
    br.frozen = Math.max(br.frozen, t);
  }

  private poison(br: Brick, stacks: number, dps: number, dur: number, toxic = false) {
    if (br.dead) return;
    br.poison = Math.max(br.poison, dur);
    br.pStacks = Math.min(8, br.pStacks + stacks);
    br.pDps = Math.max(br.pDps, dps);
    if (toxic) br.toxic = true;
  }

  private hurt(br: Brick, amt: number, crit = false, dot = false) {
    if (br.dead) return;
    br.hp -= amt;
    if (!dot) {
      br.flash = 1;
      br.pop = 1;
      if (this.texts.length < 34) {
        const t = Math.max(1, Math.round(amt));
        this.text(br.x + br.w / 2 + rand(-10, 10), br.y + 6, crit ? `${t}!` : `${t}`, crit ? "#ffd84d" : "#ffffff", crit ? 20 : 13, 0.55);
      }
    }
    if (br.hp <= 0) this.kill(br);
  }

  private arc(origin: Brick, a: { n: number; dmg: number; range: number; freeze?: number }, dmg: number, color: string) {
    let cx = origin.x + origin.w / 2;
    let cy = origin.y + origin.h / 2;
    const pts = [cx, cy];
    const used = new Set<Brick>([origin]);
    for (let i = 0; i < a.n; i++) {
      let best: Brick | null = null;
      let bd = a.range * a.range;
      for (const t of this.bricks) {
        if (t.dead || used.has(t) || t.y + t.h < PLAY_TOP) continue;
        const dx = t.x + t.w / 2 - cx;
        const dy = t.y + t.h / 2 - cy;
        const d = dx * dx + dy * dy;
        if (d < bd) {
          bd = d;
          best = t;
        }
      }
      if (!best) break;
      used.add(best);
      cx = best.x + best.w / 2;
      cy = best.y + best.h / 2;
      pts.push(cx, cy);
      this.hurt(best, dmg * a.dmg);
      if (a.freeze) this.freeze(best, a.freeze);
      this.spark(cx, cy, color, 4, 200, 0.3);
    }
    if (pts.length > 2) {
      this.bolts.push({ pts, life: 0.2, max: 0.2, color });
      this.sfx.play("bolt");
    }
  }

  private explode(x: number, y: number, r: number, dmg: number, color: string, burn?: { dps: number; dur: number }, skip?: Brick) {
    this.ring(x, y, color, r, 0.38);
    this.ring(x, y, "#ffffff", r * 0.55, 0.25);
    this.spark(x, y, color, Math.min(22, 8 + r / 8), 120 + r * 3, 0.5);
    for (let i = 0; i < 6; i++) this.puff(x + rand(-r / 3, r / 3), y + rand(-r / 3, r / 3), color, 40 + r * 0.5);
    this.shake = Math.min(26, this.shake + 2 + r / 22);
    this.sfx.play("boom");
    this.hitstop = Math.max(this.hitstop, r > 70 ? 0.05 : 0.025);
    for (const br of this.bricks) {
      if (br.dead || br === skip || br.y + br.h < PLAY_TOP) continue;
      const cx = clamp(x, br.x, br.x + br.w);
      const cy = clamp(y, br.y, br.y + br.h);
      const d = Math.hypot(x - cx, y - cy);
      if (d <= r && dmg > 0) {
        this.hurt(br, dmg * (1 - 0.4 * (d / r)));
        if (burn && !br.dead) this.ignite(br, burn.dps, burn.dur);
      }
    }
  }

  private kill(br: Brick) {
    if (br.dead) return;
    br.dead = true;
    this.kills++;
    const cx = br.x + br.w / 2;
    const cy = br.y + br.h / 2;
    const pal = this.palOf(br);
    const boss = br.type === "boss";
    const mult = 1 + Math.min(7, this.combo * 0.1);
    const typeMul = boss ? 6 : br.type === "g" ? 2 : br.type === "a" ? 1.4 : 1;
    const pts = Math.round(br.maxhp * 10 * mult * typeMul);
    this.score += pts;
    if (this.texts.length < 34 || boss) this.text(cx, cy - 4, `+${pts}`, pal.top, boss ? 30 : 15, boss ? 1.2 : 0.8);
    this.debris(cx, cy, pal.glow, boss ? 70 : 12, boss ? 520 : 260, br.w);
    this.spark(cx, cy, "#ffffff", boss ? 30 : 5, boss ? 520 : 260, 0.4);
    this.sfx.play("kill", this.combo);
    this.shake += boss ? 20 : 1.4;
    this.warp = Math.min(this.maxWarp(), this.warp + 1.1 + 0.5 * (this.passives.chrono || 0));

    // drops
    if (!this.demo) {
      let n = br.type === "g" ? 4 : br.type === "a" ? 2 : Math.random() < 0.8 ? 1 : 0;
      if (boss) n = 18;
      if (this.orbs.length > 90) n = Math.min(n, 1);
      for (let i = 0; i < n; i++) this.orb(cx + rand(-10, 10), cy + rand(-6, 6), 1, false);
      if (boss) this.orb(cx, cy, 0, true);
    }

    if (br.type === "x") {
      this.after(0.07, () => this.explode(cx, cy, 100, 5 + this.rowIndex * 0.5, "#ff5a3c", undefined, br));
    }
    if (br.poison > 0 || br.toxic) {
      for (const n of this.bricks) {
        if (n.dead || n.y + n.h < PLAY_TOP) continue;
        const d = Math.hypot(n.x + n.w / 2 - cx, n.y + n.h / 2 - cy);
        if (d < (boss ? 190 : 96)) {
          if (br.pStacks > 0) this.poison(n, Math.max(1, Math.floor(br.pStacks / 2)), br.pDps || 1, 4, br.toxic);
          if (br.toxic) this.ignite(n, 1.6, 3);
          this.spark(n.x + n.w / 2, n.y + n.h / 2, "#9dff4d", 3, 80, 0.4);
        }
      }
    }
    if (boss) {
      this.hitstop = Math.max(this.hitstop, 0.14);
      this.flash("#ff58ee", 0.7);
      this.ring(cx, cy, "#ff58ee", 260, 0.6);
      this.ring(cx, cy, "#ffffff", 160, 0.4);
      this.sfx.play("boom");
      this.showBanner("БОСС ПОВЕРЖЕН!", "+ сердце и россыпь опыта", "#ff58ee");
      this.vibrate(80);
    }
  }

  /* ───────────────────────── bricks ───────────────────────── */

  private updateBricks(dt: number) {
    let lowest = 0;
    let frozenN = 0;
    for (const br of this.bricks) {
      if (br.dead) continue;
      if (br.y + br.h > lowest && br.y + br.h > PLAY_TOP) lowest = br.y + br.h;
      if (br.frozen > 0) {
        br.frozen -= dt;
        frozenN++;
      }
      br.flash = Math.max(0, br.flash - dt * 6);
      br.pop = Math.max(0, br.pop - dt * 7);
      let dot = 0;
      if (br.burn > 0) {
        br.burn -= dt;
        dot += br.burnDps * dt;
        if (Math.random() < dt * 14) this.particle(br.x + rand(0, br.w), br.y + rand(0, br.h), rand(-15, 15), rand(-70, -30), 0.45, rand(2, 4), "#ff9a3a", 1, 0);
        if (br.burn <= 0) br.burnDps = 0;
      }
      if (br.poison > 0) {
        br.poison -= dt;
        dot += br.pStacks * br.pDps * dt;
        if (Math.random() < dt * 6) this.particle(br.x + rand(0, br.w), br.y + rand(0, br.h), rand(-10, 10), rand(-40, -15), 0.6, rand(2, 3.5), "#8dff4a", 1, 0);
        if (br.poison <= 0) {
          br.pStacks = 0;
          br.pDps = 0;
        }
      }
      if (dot > 0) {
        br.tick -= dt;
        if (br.tick <= 0) {
          br.tick = 0.3;
          br.flash = Math.max(br.flash, 0.3);
        }
        this.hurt(br, dot, false, true);
      }
    }

    // scroll speed with rubber band
    let f = 1;
    if (lowest < 300) f = 1 + ((300 - lowest) / 200) * 4;
    else if (lowest > 560) f = Math.max(0.4, 1 - (lowest - 560) / 400);
    const depth = Math.max(0, this.rowIndex - 7);
    let speed = 9 + Math.min(depth, 70) * 0.26;
    speed *= 1 - 0.1 * (this.passives.chill || 0);
    speed *= 1 - Math.min(0.5, frozenN * 0.04);
    if (this.demo) speed = Math.max(speed, 16);
    const d = speed * f * dt;
    this.accum += d;
    this.gridOff = (this.gridOff + d) % 48;
    for (const br of this.bricks) if (!br.dead) br.y += d;
    while (this.accum >= ROW_H) {
      this.accum -= ROW_H;
      this.spawnRow(PLAY_TOP - ROW_H + this.accum);
    }

    // breach
    this.danger += (clamp((lowest - (DANGER_Y - 130)) / 130, 0, 1) - this.danger) * Math.min(1, dt * 5);
    for (const br of this.bricks) {
      if (br.dead) continue;
      if (br.y + br.h >= DANGER_Y) this.breach(br);
    }
    this.bricks = this.bricks.filter((b) => !b.dead);
  }

  private breach(br: Brick) {
    if (!this.demo && this.hp <= 0) return;
    br.dead = true;
    const cx = br.x + br.w / 2;
    const cy = br.y + br.h / 2;
    this.debris(cx, cy, "#ff3355", 30, 400, br.w);
    this.explode(cx, DANGER_Y, 60, 0, "#ff3355");
    if (this.demo) return;
    const dmg = br.type === "boss" ? 2 : 1;
    this.hp -= dmg;
    this.shake = 28;
    this.flash("#ff1f44", 0.55);
    this.sfx.play("breach");
    this.vibrate(120);
    this.combo = 0;
    this.showBanner(this.hp > 0 ? "СТЕНА ПРОРВАНА!" : "", this.hp > 0 ? `осталось жизней: ${this.hp}` : "", "#ff3355");
    if (this.hp <= 0) this.gameOver();
  }

  private spawnRow(y: number) {
    const d = this.rowIndex++;
    const boss = d > 10 && d % BOSS_EVERY === BOSS_EVERY - 1;
    const skip = boss || this.skipCenter > 0;
    if (this.skipCenter > 0 && !boss) this.skipCenter--;
    if (boss) {
      this.skipCenter = 1;
      const hp = 55 + d * 9;
      const bx = MARGIN + 2 * CW + GAP / 2;
      this.mk(bx, y - ROW_H + GAP / 2, 5 * CW - GAP, 2 * ROW_H - GAP, hp, "boss");
      this.showBanner("⚠ БОСС ⚠", "бей по самому сердцу!", "#ff58ee");
      this.sfx.play("breach");
    } else if (d > 0 && d % 10 === 0 && !this.demo) {
      this.showBanner(`ГЛУБИНА ${Math.max(0, d - 7)}`, "", "#7ff");
    }
    const dens = Math.min(0.9, 0.6 + d * 0.012);
    const mirror = Math.random() < 0.55;
    const r1: number[] = [];
    const r2: number[] = [];
    for (let i = 0; i < COLS; i++) {
      r1.push(Math.random());
      r2.push(Math.random());
    }
    const pA = d >= 3 ? Math.min(0.22, 0.04 + d * 0.008) : 0;
    const pX = d >= 2 ? 0.06 : 0;
    const pG = d >= 1 ? 0.07 : 0;
    for (let c = 0; c < COLS; c++) {
      if (skip && c >= 2 && c <= 6) continue;
      const cc = mirror ? Math.min(c, COLS - 1 - c) : c;
      if (r1[cc] > dens) continue;
      const base = 1 + Math.floor(d * 0.34 + Math.random() * (1 + d * 0.1));
      const t = r2[cc];
      let type: Brick["type"] = "n";
      let hp = base;
      if (t < pX) {
        type = "x";
        hp = Math.max(1, Math.round(base * 0.6));
      } else if (t < pX + pG) {
        type = "g";
      } else if (t < pX + pG + pA) {
        type = "a";
        hp = Math.round(base * 2.2) + 1;
      }
      this.mk(MARGIN + c * CW + GAP / 2, y + GAP / 2, CW - GAP, ROW_H - GAP, hp, type);
    }
  }

  private mk(x: number, y: number, w: number, h: number, hp: number, type: Brick["type"]) {
    this.bricks.push({
      id: this.brickId++,
      x,
      y,
      w,
      h,
      hp,
      maxhp: hp,
      type,
      flash: 0,
      pop: 0,
      burn: 0,
      burnDps: 0,
      poison: 0,
      pStacks: 0,
      pDps: 0,
      frozen: 0,
      toxic: false,
      dead: false,
      tick: 0,
    });
  }

  private palOf(br: Brick): Pal {
    switch (br.type) {
      case "a":
        return PAL_ARMOR;
      case "x":
        return PAL_TNT;
      case "g":
        return PAL_GEM;
      case "boss":
        return PAL_BOSS;
      default:
        return PAL[tierOf(br.hp)];
    }
  }

  /* ───────────────────────── orbs & progression ───────────────────────── */

  private orb(x: number, y: number, v: number, heart: boolean) {
    this.orbs.push({ x, y, vx: rand(-130, 130), vy: rand(-320, -120), v, heart, t: 0 });
  }

  private updateOrbs(dt: number) {
    const pw = this.pw();
    const magR = 100 + 60 * (this.passives.magnet || 0);
    for (let i = this.orbs.length - 1; i >= 0; i--) {
      const o = this.orbs[i];
      o.t += dt;
      o.vy += 650 * dt;
      const dx = this.px - o.x;
      const dy = PADDLE_Y - o.y;
      const d = Math.hypot(dx, dy);
      if (d < magR && o.t > 0.3 && o.y < PADDLE_Y + 20) {
        const pull = 2600 * (1 - d / magR) + 500;
        o.vx += (dx / d) * pull * dt;
        o.vy += (dy / d) * pull * dt;
        o.vx *= 1 - Math.min(1, dt * 3);
      }
      o.x += o.vx * dt;
      o.y += o.vy * dt;
      if (o.x < 10) {
        o.x = 10;
        o.vx = Math.abs(o.vx);
      } else if (o.x > W - 10) {
        o.x = W - 10;
        o.vx = -Math.abs(o.vx);
      }
      if (o.y >= PADDLE_Y - 8 && o.y <= PADDLE_Y + PADDLE_H + 14 && Math.abs(o.x - this.px) < pw / 2 + 10 && o.t > 0.15) {
        this.orbs.splice(i, 1);
        this.collect(o);
        continue;
      }
      if (o.y > H + 30) this.orbs.splice(i, 1);
      else if (Math.random() < dt * 20) this.particle(o.x, o.y, 0, 20, 0.3, 2, o.heart ? "#ff6b8a" : "#58ffe2", 1, 0);
    }
  }

  private collect(o: Orb) {
    if (o.heart) {
      if (this.hp < this.maxHp) {
        this.hp++;
        this.sfx.play("heal");
        this.text(this.px, PADDLE_Y - 30, "+1 ❤", "#ff6b8a", 22, 0.9);
      } else {
        this.score += 500;
        this.text(this.px, PADDLE_Y - 30, "+500", "#ff6b8a", 20, 0.9);
      }
      this.ring(this.px, PADDLE_Y, "#ff6b8a", 70, 0.4);
    } else {
      this.xp += o.v;
      this.orbChain++;
      this.orbChainT = 0.6;
      this.sfx.play("orb", this.orbChain);
    }
    this.spark(o.x, PADDLE_Y, o.heart ? "#ff6b8a" : "#58ffe2", 5, 180, 0.3);
  }

  private openLevelUp() {
    this.pending--;
    this.choices = this.makeCards();
    this.sfx.play("levelup");
    this.ring(this.px, PADDLE_Y, "#58ffe2", 160, 0.6);
    this.vibrate(30);
    this.setScreen("levelup");
    this.cb.onCards(this.choices);
  }

  private totalBalls() {
    return (Object.keys(this.arsenal) as Kind[]).reduce((s, k) => s + this.arsenal[k].count, 0);
  }

  private makeCards(): Card[] {
    const cands: { card: Card; w: number }[] = [];
    const total = this.totalBalls();
    const early = this.level <= 3;
    const A = this.arsenal;
    // balls that can be fused with something we already own get picked more often
    const synergy = (k: Kind) =>
      FUSION_KINDS.some((f) => {
        const [x, y] = KINDS[f].fusion!;
        if (A[f].count > 0 || A[f].level > 0) return false;
        const other = x === k ? y : y === k ? x : null;
        return other !== null && A[other].count > 0;
      })
        ? 2.2
        : 1;
    for (const k of BASE_KINDS) {
      const def = KINDS[k];
      const a = A[k];
      if (k === "normal") {
        if (a.count < 8 && total < MAX_BALLS)
          cands.push({
            w: 0.7,
            card: { id: "ball:normal", type: "ball", tag: "+1 ШАР", title: `${def.name} ×${a.count + 1}`, desc: "Ещё один надёжный шар в залпе.", icon: def.icon, color: def.color, sub: `Шаров: ${a.count} → ${a.count + 1}` },
          });
        continue;
      }
      if (a.count === 0 && a.level === 0) {
        cands.push({ w: (early ? 6 : 3) * synergy(k), card: { id: `ball:${k}`, type: "ball", tag: "НОВЫЙ ШАР", title: def.name, desc: def.desc, icon: def.icon, color: def.color, sub: "Добавляется в залп" } });
      } else {
        if (a.count < 6 && total < MAX_BALLS)
          cands.push({ w: 1.5, card: { id: `ball:${k}`, type: "ball", tag: "+1 ШАР", title: `${def.name} ×${a.count + 1}`, desc: def.desc, icon: def.icon, color: def.color, sub: `Шаров: ${a.count} → ${a.count + 1}` } });
        if (a.level < 6)
          cands.push({ w: (a.level < 2 ? 3.5 : 2) * synergy(k), card: { id: `lvl:${k}`, type: "level", tag: "УЛУЧШЕНИЕ", title: `${def.name}: ур. ${a.level + 1}`, desc: UPGRADE_TEXT[k], icon: def.icon, color: def.color, sub: `Уровень ${a.level} → ${a.level + 1}` } });
      }
    }
    for (const f of FUSION_KINDS) {
      const def = KINDS[f];
      const [x, y] = def.fusion!;
      const a = A[f];
      if (a.count > 0 || a.level > 0) {
        if (a.level < 6) cands.push({ w: 2.5, card: { id: `lvl:${f}`, type: "level", tag: "УЛУЧШЕНИЕ", title: `${def.name}: ур. ${a.level + 1}`, desc: UPGRADE_TEXT[f], icon: def.icon, color: def.color, sub: `Уровень ${a.level} → ${a.level + 1}` } });
        if (a.count < 4 && total < MAX_BALLS) cands.push({ w: 1.2, card: { id: `ball:${f}`, type: "ball", tag: "+1 ШАР", title: `${def.name} ×${a.count + 1}`, desc: def.desc, icon: def.icon, color: def.color, sub: `Шаров: ${a.count} → ${a.count + 1}` } });
      } else if (A[x].count > 0 && A[y].count > 0 && A[x].level >= 2 && A[y].level >= 2) {
        cands.push({ w: 100, card: { id: `fuse:${f}`, type: "fusion", tag: "⚗ СЛИЯНИЕ", title: def.name, desc: def.desc, icon: def.icon, color: "#ffd84d", sub: `${KINDS[x].icon} + ${KINDS[y].icon} → 2 шара ${def.icon}` } });
      }
    }
    for (const p of PASSIVES) {
      const l = this.passives[p.id] || 0;
      if (l < p.max) cands.push({ w: early ? 1 : 1.6, card: { id: `pas:${p.id}`, type: "passive", tag: "ПАССИВКА", title: p.name, desc: p.desc(l + 1), icon: p.icon, color: "#9bb4ff", sub: `Уровень ${l} → ${l + 1} (макс ${p.max})` } });
    }

    const picks: Card[] = [];
    const pool = cands.slice();
    while (picks.length < 3 && pool.length) {
      const sum = pool.reduce((s, c) => s + c.w, 0);
      let r = Math.random() * sum;
      let idx = 0;
      for (; idx < pool.length - 1; idx++) {
        r -= pool[idx].w;
        if (r <= 0) break;
      }
      picks.push(pool[idx].card);
      pool.splice(idx, 1);
    }
    if (!picks.some((c) => c.type === "ball" || c.type === "fusion")) {
      const alt = cands.filter((c) => c.card.type === "ball" && !picks.includes(c.card));
      if (alt.length) picks[picks.length - 1] = alt[Math.floor(Math.random() * alt.length)].card;
    }
    return picks;
  }

  private applyCard(id: string) {
    const [t, k] = id.split(":");
    if (t === "ball") {
      const a = this.arsenal[k as Kind];
      a.count++;
      if (a.level === 0) a.level = 1;
      this.text(this.px, PADDLE_Y - 40, `+ ${KINDS[k as Kind].name}`, KINDS[k as Kind].color, 22, 1);
      this.deploy(k as Kind, 1);
    } else if (t === "lvl") {
      this.arsenal[k as Kind].level++;
    } else if (t === "fuse") {
      const def = KINDS[k as Kind];
      const [x, y] = def.fusion!;
      this.arsenal[x].count--;
      this.arsenal[y].count--;
      this.arsenal[k as Kind] = { count: 2, level: 1 };
      // swap one in-flight ingredient ball of each type for the fused ones
      for (const ing of [x, y]) {
        const i = this.balls.findIndex((bb) => bb.kind === ing);
        if (i >= 0) {
          this.balls.splice(i, 1);
          this.volleySize--;
        }
      }
      this.deploy(k as Kind, 2);
      this.sfx.play("fuse");
      this.flash("#ffd84d", 0.6);
      this.shake = 18;
      this.ring(this.px, PADDLE_Y, "#ffd84d", 240, 0.7);
      this.spark(this.px, PADDLE_Y, "#ffd84d", 26, 500, 0.8);
      this.showBanner(`СЛИЯНИЕ: ${def.name.toUpperCase()}`, def.desc, "#ffd84d");
      this.vibrate(60);
    } else if (t === "pas") {
      this.passives[k] = (this.passives[k] || 0) + 1;
      if (k === "hp") {
        this.maxHp++;
        this.hp = Math.min(this.maxHp, this.hp + 1);
      }
      if (k === "wide") this.ptarget = clamp(this.ptarget, this.pw() / 2, W - this.pw() / 2);
    }
  }

  private gameOver() {
    this.sfx.play("gameover");
    this.flash("#ff1f44", 0.8);
    this.vibrate(250);
    this.hitstop = 0;
    this.timeScale = 1;
    const bs = this.bricks.filter((b) => !b.dead);
    bs.forEach((b, i) => {
      this.after(0.05 + i * 0.012, () => {
        this.debris(b.x + b.w / 2, b.y + b.h / 2, this.palOf(b).glow, 8, 300, b.w);
        this.shake = Math.max(this.shake, 4);
      });
    });
    this.after(0.05 + bs.length * 0.012, () => {
      this.bricks = [];
    });
    this.balls = [];
    this.setScreen("gameover");
    this.cb.onGameOver({
      score: this.score,
      depth: Math.max(0, this.rowIndex - 7),
      level: this.level,
      kills: this.kills,
      maxCombo: this.maxCombo,
      perfects: this.perfects,
    });
  }

  /* ───────────────────────── particles & text ───────────────────────── */

  private vibrate(ms: number) {
    try {
      if (!this.sfx.muted && navigator.vibrate) navigator.vibrate(ms);
    } catch {
      /* ignore */
    }
  }

  private flash(color: string, a: number) {
    this.flashColor = color;
    this.flashA = a;
  }

  private showBanner(text: string, sub: string, color: string) {
    if (!text) return;
    this.bannerText = text;
    this.bannerSub = sub;
    this.bannerColor = color;
    this.bannerT = 2;
  }

  private particle(x: number, y: number, vx: number, vy: number, life: number, size: number, color: string, kind: 0 | 1 | 2 | 3, g: number) {
    if (this.parts.length > 650 && kind !== 3) return;
    this.parts.push({ x, y, vx, vy, life, max: life, size, color, kind, g });
  }

  private spark(x: number, y: number, color: string, n: number, speed: number, life: number) {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2;
      const s = speed * rand(0.3, 1);
      this.particle(x, y, Math.cos(a) * s, Math.sin(a) * s, life * rand(0.6, 1), 1.5, color, 2, 0);
    }
  }

  private debris(x: number, y: number, color: string, n: number, speed: number, spread: number) {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2;
      const s = speed * rand(0.2, 1);
      this.particle(x + rand(-spread / 2, spread / 2) * 0.6, y + rand(-8, 8), Math.cos(a) * s, Math.sin(a) * s - 80, rand(0.5, 1), rand(2.5, 6), color, 0, 900);
    }
  }

  private ring(x: number, y: number, color: string, r: number, life: number) {
    this.particle(x, y, 0, 0, life, r, color, 3, 0);
  }

  private puff(x: number, y: number, color: string, r: number) {
    this.particle(x, y, rand(-40, 40), rand(-40, 40), rand(0.25, 0.5), r * rand(0.25, 0.45), color, 1, 0);
  }

  private text(x: number, y: number, text: string, color: string, size: number, life: number) {
    this.texts.push({ x, y, text, life, max: life, color, size });
  }

  private updateParticles(dt: number) {
    const ps = this.parts;
    for (let i = ps.length - 1; i >= 0; i--) {
      const p = ps[i];
      p.life -= dt;
      if (p.life <= 0) {
        ps[i] = ps[ps.length - 1];
        ps.pop();
        continue;
      }
      if (p.kind === 3) continue;
      p.vy += p.g * dt;
      const drag = p.kind === 2 ? 3 : 1;
      p.vx *= 1 - Math.min(1, drag * dt);
      p.vy *= 1 - Math.min(1, drag * dt * (p.g ? 0.3 : 1));
      p.x += p.vx * dt;
      p.y += p.vy * dt;
    }
  }

  private updateTexts(dt: number) {
    for (let i = this.texts.length - 1; i >= 0; i--) {
      const t = this.texts[i];
      t.life -= dt;
      t.y -= 42 * dt;
      if (t.life <= 0) this.texts.splice(i, 1);
    }
  }

  /* ───────────────────────── rendering ───────────────────────── */

  private render() {
    const ctx = this.ctx;
    const s = this.scale;
    if (!this.bg) return;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = "source-over";
    ctx.drawImage(this.bg, 0, 0);

    const sx = this.shake ? rand(-1, 1) * this.shake : 0;
    const sy = this.shake ? rand(-1, 1) * this.shake : 0;
    ctx.setTransform(s, 0, 0, s, sx * s, sy * s);

    // clip to play field for scrolling elements
    ctx.save();
    ctx.beginPath();
    ctx.rect(-40, PLAY_TOP, W + 80, H - PLAY_TOP + 40);
    ctx.clip();

    // scrolling grid
    ctx.strokeStyle = "rgba(140,110,255,0.06)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    for (let y = PLAY_TOP + this.gridOff; y < H; y += 48) {
      ctx.moveTo(0, y);
      ctx.lineTo(W, y);
    }
    ctx.stroke();

    // danger zone
    const pulse = 0.5 + 0.5 * Math.sin(this.time * 8);
    const dg = ctx.createLinearGradient(0, DANGER_Y - 60, 0, DANGER_Y + 60);
    dg.addColorStop(0, "rgba(255,30,70,0)");
    dg.addColorStop(1, `rgba(255,30,70,${0.1 + this.danger * (0.25 + 0.15 * pulse)})`);
    ctx.fillStyle = dg;
    ctx.fillRect(0, DANGER_Y - 60, W, H - DANGER_Y + 60);
    ctx.strokeStyle = `rgba(255,70,100,${0.35 + this.danger * 0.5 * pulse})`;
    ctx.lineWidth = 2;
    ctx.setLineDash([12, 10]);
    ctx.beginPath();
    ctx.moveTo(0, DANGER_Y);
    ctx.lineTo(W, DANGER_Y);
    ctx.stroke();
    ctx.setLineDash([]);

    // net
    if (this.net > 0) {
      ctx.strokeStyle = `rgba(100,255,255,${0.6 + 0.3 * pulse})`;
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(0, NET_Y);
      ctx.lineTo(W, NET_Y);
      ctx.stroke();
      ctx.lineWidth = 1;
      ctx.strokeStyle = "rgba(100,255,255,0.3)";
      ctx.beginPath();
      for (let x = 0; x < W; x += 18) {
        ctx.moveTo(x, NET_Y);
        ctx.lineTo(x + 9, NET_Y + 20);
        ctx.moveTo(x + 18, NET_Y);
        ctx.lineTo(x + 9, NET_Y + 20);
      }
      ctx.stroke();
    }

    this.drawBricks(ctx);
    ctx.restore();

    this.drawOrbs(ctx);
    this.drawBalls(ctx);
    this.drawPaddle(ctx);
    this.drawFx(ctx);

    // HUD (no shake)
    ctx.setTransform(s, 0, 0, s, 0, 0);
    if (this.screen !== "menu") this.drawHud(ctx);
    else this.drawMenuHud(ctx);

    // overlay flash
    if (this.flashA > 0.01) {
      ctx.globalAlpha = this.flashA * 0.5;
      ctx.fillStyle = this.flashColor;
      ctx.fillRect(0, 0, W, H);
      ctx.globalAlpha = 1;
    }
    // slow-mo tint
    if (this.timeScale < 0.95) {
      ctx.globalAlpha = (1 - this.timeScale) * 0.25;
      ctx.fillStyle = "#3a6bff";
      ctx.fillRect(0, 0, W, H);
      ctx.globalAlpha = 1;
    }
  }

  private drawBricks(ctx: CanvasRenderingContext2D) {
    ctx.font = `bold 15px ${FONT}`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    for (const br of this.bricks) {
      if (br.dead || br.y + br.h < PLAY_TOP - 2) continue;
      const pal = this.palOf(br);
      const pp = br.pop * 2.5;
      const x = br.x - pp;
      const y = br.y - pp;
      const w = br.w + pp * 2;
      const h = br.h + pp * 2;
      const boss = br.type === "boss";
      // glow-ish outline for special
      if (boss || br.type === "x" || br.type === "g") {
        ctx.fillStyle = pal.glow;
        ctx.globalAlpha = 0.18 + 0.1 * Math.sin(this.time * 5 + br.id);
        rr(ctx, x - 3, y - 3, w + 6, h + 6, 8);
        ctx.fill();
        ctx.globalAlpha = 1;
      }
      ctx.fillStyle = pal.dark;
      rr(ctx, x, y + 2, w, h, 5);
      ctx.fill();
      ctx.fillStyle = pal.body;
      rr(ctx, x, y, w, h - 1, 5);
      ctx.fill();
      ctx.fillStyle = pal.top;
      ctx.globalAlpha = 0.55;
      rr(ctx, x + 2, y + 2, w - 4, boss ? 6 : 5, 3);
      ctx.fill();
      ctx.globalAlpha = 1;

      if (br.type === "a") {
        ctx.fillStyle = pal.dark;
        for (const [ox, oy] of [[5, 5], [w - 5, 5], [5, h - 6], [w - 5, h - 6]]) {
          ctx.beginPath();
          ctx.arc(x + ox, y + oy, 1.8, 0, 6.283);
          ctx.fill();
        }
      } else if (br.type === "x") {
        ctx.save();
        rr(ctx, x, y, w, h, 5);
        ctx.clip();
        ctx.strokeStyle = "rgba(60,0,0,0.45)";
        ctx.lineWidth = 3;
        ctx.beginPath();
        for (let k = -2; k < 4; k++) {
          ctx.moveTo(x + k * 14, y + h);
          ctx.lineTo(x + k * 14 + h, y);
        }
        ctx.stroke();
        ctx.restore();
      } else if (br.type === "g") {
        ctx.fillStyle = "rgba(255,255,255,0.35)";
        ctx.beginPath();
        ctx.moveTo(x + w / 2, y + 4);
        ctx.lineTo(x + w - 8, y + h / 2);
        ctx.lineTo(x + w / 2, y + h - 5);
        ctx.lineTo(x + 8, y + h / 2);
        ctx.closePath();
        ctx.fill();
      } else if (boss) {
        // eye
        const ex = x + w / 2;
        const ey = y + h / 2;
        ctx.fillStyle = "#1c0830";
        ctx.beginPath();
        ctx.ellipse(ex, ey, 46, 20, 0, 0, 6.283);
        ctx.fill();
        ctx.fillStyle = "#ff58ee";
        ctx.beginPath();
        ctx.arc(ex + Math.sin(this.time * 1.5) * 14, ey, 11, 0, 6.283);
        ctx.fill();
        ctx.fillStyle = "#fff";
        ctx.beginPath();
        ctx.arc(ex + Math.sin(this.time * 1.5) * 14 - 3, ey - 3, 3, 0, 6.283);
        ctx.fill();
      }

      // status overlays
      if (br.frozen > 0) {
        ctx.fillStyle = "rgba(170,240,255,0.5)";
        rr(ctx, x, y, w, h, 5);
        ctx.fill();
        ctx.strokeStyle = "rgba(255,255,255,0.8)";
        ctx.lineWidth = 1.5;
        ctx.stroke();
      }
      if (br.burn > 0) {
        ctx.fillStyle = `rgba(255,120,30,${0.25 + 0.15 * Math.sin(this.time * 18 + br.id)})`;
        rr(ctx, x, y, w, h, 5);
        ctx.fill();
      }
      if (br.poison > 0) {
        ctx.fillStyle = "rgba(120,255,60,0.25)";
        rr(ctx, x, y, w, h, 5);
        ctx.fill();
      }
      if (br.flash > 0) {
        ctx.fillStyle = `rgba(255,255,255,${br.flash * 0.85})`;
        rr(ctx, x, y, w, h, 5);
        ctx.fill();
      }
      // hp
      if (!boss) {
        ctx.fillStyle = br.type === "a" ? "#10142a" : "rgba(10,0,30,0.85)";
        ctx.fillText(String(Math.ceil(br.hp)), x + w / 2, y + h / 2 + 1);
      } else {
        ctx.font = `bold 22px ${FONT}`;
        ctx.fillStyle = "#fff";
        ctx.fillText(String(Math.ceil(br.hp)), x + w / 2, y + h - 14);
        ctx.font = `bold 15px ${FONT}`;
      }
    }
  }

  private drawOrbs(ctx: CanvasRenderingContext2D) {
    ctx.globalCompositeOperation = "lighter";
    for (const o of this.orbs) {
      const g = glowSprite(o.heart ? "#ff4d77" : "#35ffe0");
      const sz = o.heart ? 30 : 20;
      ctx.drawImage(g, o.x - sz / 2, o.y - sz / 2, sz, sz);
    }
    ctx.globalCompositeOperation = "source-over";
    for (const o of this.orbs) {
      if (o.heart) {
        ctx.fillStyle = "#fff";
        ctx.font = "bold 16px sans-serif";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText("♥", o.x, o.y + 1);
      } else {
        ctx.fillStyle = "#e6fffb";
        ctx.beginPath();
        ctx.moveTo(o.x, o.y - 4.5);
        ctx.lineTo(o.x + 3.5, o.y);
        ctx.lineTo(o.x, o.y + 4.5);
        ctx.lineTo(o.x - 3.5, o.y);
        ctx.closePath();
        ctx.fill();
      }
    }
  }

  private drawBalls(ctx: CanvasRenderingContext2D) {
    // ready balls hovering on paddle
    if (this.phase === "ready" && this.screen !== "gameover") {
      const q = this.buildQueueCounts();
      const n = q.length;
      for (let i = 0; i < n; i++) {
        const a = -Math.PI / 2 + (i - (n - 1) / 2) * 0.16;
        const rad = 22 + Math.sin(this.time * 6 + i) * 1.5;
        const x = this.px + Math.cos(a) * rad * (n > 1 ? 1.3 : 0);
        const y = PADDLE_Y - 14 + Math.sin(a) * rad * 0.6 - (n > 1 ? 0 : 20);
        this.drawBall(ctx, x, y, q[i], false, null);
      }
    }
    ctx.globalCompositeOperation = "lighter";
    for (const b of this.balls) {
      const col = KINDS[b.kind].color;
      const g = glowSprite(col);
      const tl = b.trail.length;
      for (let i = 0; i < tl; i++) {
        const t = b.trail[i];
        const k = 1 - i / tl;
        ctx.globalAlpha = k * 0.4;
        const sz = 30 * (0.35 + 0.65 * k);
        ctx.drawImage(g, t.x - sz / 2, t.y - sz / 2, sz, sz);
      }
      ctx.globalAlpha = 1;
      const gs = b.charged ? 52 : 38;
      ctx.drawImage(glowSprite(b.charged ? "#ffd84d" : col), b.x - gs / 2, b.y - gs / 2, gs, gs);
    }
    ctx.globalCompositeOperation = "source-over";
    for (const b of this.balls) this.drawBall(ctx, b.x, b.y, b.kind, b.charged, b);
  }

  private buildQueueCounts(): Kind[] {
    const q: Kind[] = [];
    (Object.keys(this.arsenal) as Kind[]).forEach((k) => {
      for (let i = 0; i < this.arsenal[k].count; i++) q.push(k);
    });
    return q.slice(0, 12);
  }

  private drawBall(ctx: CanvasRenderingContext2D, x: number, y: number, kind: Kind, charged: boolean, b: Ball | null) {
    const col = KINDS[kind].color;
    const r = BALL_R + (b && b.pierceLeft > 0 ? 0 : 0);
    ctx.fillStyle = col;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, 6.283);
    ctx.fill();
    ctx.fillStyle = "rgba(255,255,255,0.9)";
    ctx.beginPath();
    ctx.arc(x - 2, y - 2, r * 0.42, 0, 6.283);
    ctx.fill();
    ctx.strokeStyle = charged ? "#ffd84d" : "rgba(255,255,255,0.7)";
    ctx.lineWidth = charged ? 2.5 : 1.2;
    ctx.beginPath();
    ctx.arc(x, y, r + (charged ? 2 + Math.sin(this.time * 20) : 0), 0, 6.283);
    ctx.stroke();
  }

  private drawPaddle(ctx: CanvasRenderingContext2D) {
    if (this.screen === "gameover") return;
    const pw = this.pw();
    const pop = this.padPop;
    const w = pw * (1 + pop * 0.06);
    const h = PADDLE_H * (1 - pop * 0.25);
    const x = this.px - w / 2;
    const y = PADDLE_Y + (PADDLE_H - h);
    // glow
    ctx.globalCompositeOperation = "lighter";
    ctx.drawImage(glowSprite("#7a4dff"), this.px - w / 2 - 20, PADDLE_Y - 24, w + 40, 62);
    ctx.globalCompositeOperation = "source-over";
    const g = ctx.createLinearGradient(x, 0, x + w, 0);
    g.addColorStop(0, "#ff4de3");
    g.addColorStop(0.5, "#8d6bff");
    g.addColorStop(1, "#3de6ff");
    ctx.fillStyle = g;
    rr(ctx, x, y, w, h, 7);
    ctx.fill();
    ctx.fillStyle = "rgba(255,255,255,0.45)";
    rr(ctx, x + 4, y + 1.5, w - 8, 3, 2);
    ctx.fill();
    // perfect zone
    const pwz = (0.15 + 0.06 * (this.passives.parry || 0)) * (pw / 2);
    ctx.fillStyle = "#ffd84d";
    ctx.globalAlpha = 0.85;
    rr(ctx, this.px - pwz, y + 1, pwz * 2, h - 2, 3);
    ctx.fill();
    ctx.globalAlpha = 1;
  }

  private drawFx(ctx: CanvasRenderingContext2D) {
    // bolts
    for (const b of this.bolts) {
      const k = b.life / b.max;
      ctx.lineJoin = "round";
      ctx.lineCap = "round";
      for (let pass = 0; pass < 2; pass++) {
        ctx.strokeStyle = pass === 0 ? b.color : "#ffffff";
        ctx.globalAlpha = pass === 0 ? 0.6 * k : k;
        ctx.lineWidth = pass === 0 ? 7 : 2.2;
        ctx.beginPath();
        ctx.moveTo(b.pts[0], b.pts[1]);
        for (let i = 2; i < b.pts.length; i += 2) {
          const x0 = b.pts[i - 2];
          const y0 = b.pts[i - 1];
          const x1 = b.pts[i];
          const y1 = b.pts[i + 1];
          const segs = 4;
          for (let s = 1; s < segs; s++) {
            const t = s / segs;
            ctx.lineTo(x0 + (x1 - x0) * t + rand(-9, 9), y0 + (y1 - y0) * t + rand(-9, 9));
          }
          ctx.lineTo(x1, y1);
        }
        ctx.stroke();
      }
    }
    ctx.globalAlpha = 1;

    // particles
    ctx.globalCompositeOperation = "lighter";
    for (const p of this.parts) {
      const k = p.life / p.max;
      ctx.globalAlpha = Math.min(1, k * 1.5);
      if (p.kind === 3) {
        const e = 1 - k;
        const r = p.size * (1 - (1 - e) * (1 - e));
        ctx.strokeStyle = p.color;
        ctx.lineWidth = 1 + 5 * k;
        ctx.beginPath();
        ctx.arc(p.x, p.y, r, 0, 6.283);
        ctx.stroke();
      } else if (p.kind === 2) {
        ctx.strokeStyle = p.color;
        ctx.lineWidth = 1.6;
        ctx.beginPath();
        ctx.moveTo(p.x, p.y);
        ctx.lineTo(p.x - p.vx * 0.04, p.y - p.vy * 0.04);
        ctx.stroke();
      } else if (p.kind === 1) {
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size * (0.4 + 0.6 * k), 0, 6.283);
        ctx.fill();
      } else {
        ctx.fillStyle = p.color;
        const s = p.size * (0.4 + 0.6 * k);
        ctx.fillRect(p.x - s / 2, p.y - s / 2, s, s);
      }
    }
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = "source-over";

    // floating text
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    for (const t of this.texts) {
      const k = t.life / t.max;
      const pop = 1 + Math.max(0, k - 0.8) * 2.5;
      ctx.globalAlpha = Math.min(1, k * 2);
      ctx.font = `bold ${Math.round(t.size * pop)}px ${FONT}`;
      ctx.lineWidth = 3;
      ctx.strokeStyle = "rgba(10,0,30,0.8)";
      ctx.strokeText(t.text, t.x, t.y);
      ctx.fillStyle = t.color;
      ctx.fillText(t.text, t.x, t.y);
    }
    ctx.globalAlpha = 1;
  }

  private drawMenuHud(ctx: CanvasRenderingContext2D) {
    ctx.fillStyle = "rgba(255,255,255,0.06)";
    ctx.fillRect(0, 0, W, PLAY_TOP - 2);
  }

  private drawHud(ctx: CanvasRenderingContext2D) {
    ctx.textBaseline = "alphabetic";
    // score
    ctx.textAlign = "left";
    ctx.fillStyle = "#8f86c9";
    ctx.font = `bold 11px ${FONT}`;
    ctx.fillText("ОЧКИ", 18, 22);
    ctx.fillStyle = "#fff";
    ctx.font = `bold 30px ${FONT}`;
    ctx.fillText(Math.round(this.shownScore).toLocaleString("ru-RU"), 18, 52);
    // depth
    ctx.textAlign = "center";
    ctx.fillStyle = "#8f86c9";
    ctx.font = `bold 11px ${FONT}`;
    ctx.fillText("ГЛУБИНА", W / 2 + 20, 22);
    ctx.fillStyle = "#7ff";
    ctx.font = `bold 30px ${FONT}`;
    ctx.fillText(String(Math.max(0, this.rowIndex - 7)), W / 2 + 20, 52);
    // pause button
    ctx.fillStyle = "rgba(255,255,255,0.1)";
    ctx.beginPath();
    ctx.arc(500, 36, 20, 0, 6.283);
    ctx.fill();
    ctx.fillStyle = "#fff";
    ctx.fillRect(493, 27, 5, 18);
    ctx.fillRect(502, 27, 5, 18);

    // hearts
    ctx.textAlign = "left";
    ctx.font = `20px sans-serif`;
    for (let i = 0; i < this.maxHp; i++) {
      ctx.fillStyle = i < this.hp ? "#ff4d77" : "rgba(255,255,255,0.15)";
      const beat = i < this.hp && this.hp === 1 ? 1 + 0.15 * Math.sin(this.time * 10) : 1;
      ctx.save();
      ctx.translate(26 + i * 24, 84);
      ctx.scale(beat, beat);
      ctx.textAlign = "center";
      ctx.fillText("♥", 0, 0);
      ctx.restore();
    }
    // xp
    ctx.textAlign = "left";
    ctx.fillStyle = "#58ffe2";
    ctx.font = `bold 13px ${FONT}`;
    ctx.fillText(`УР ${this.level}`, 190, 85);
    const bx = 245;
    const bw = 275;
    ctx.fillStyle = "rgba(255,255,255,0.1)";
    rr(ctx, bx, 73, bw, 12, 6);
    ctx.fill();
    const xg = ctx.createLinearGradient(bx, 0, bx + bw, 0);
    xg.addColorStop(0, "#35ffe0");
    xg.addColorStop(1, "#7a6bff");
    ctx.fillStyle = xg;
    rr(ctx, bx, 73, Math.max(10, bw * clamp(this.xpShown, 0, 1)), 12, 6);
    ctx.fill();

    // combo
    if (this.combo >= 3) {
      const mult = 1 + Math.min(7, this.combo * 0.1);
      const pop = 1 + this.comboPop * 0.25;
      ctx.save();
      ctx.translate(18, PADDLE_Y - 110);
      ctx.scale(pop, pop);
      ctx.globalAlpha = 0.9;
      ctx.fillStyle = mult > 4 ? "#ffd84d" : mult > 2 ? "#ff9a3a" : "#fff";
      ctx.font = `bold 44px ${FONT}`;
      ctx.textAlign = "left";
      ctx.lineWidth = 4;
      ctx.strokeStyle = "rgba(10,0,30,0.7)";
      ctx.strokeText(`×${mult.toFixed(1)}`, 0, 0);
      ctx.fillText(`×${mult.toFixed(1)}`, 0, 0);
      ctx.font = `bold 13px ${FONT}`;
      ctx.fillStyle = "#cbbfff";
      ctx.fillText(`КОМБО ${this.combo}`, 2, 20);
      ctx.fillStyle = "rgba(255,255,255,0.2)";
      ctx.fillRect(2, 28, 90, 4);
      ctx.fillStyle = "#fff";
      ctx.fillRect(2, 28, 90 * clamp(this.comboT / 2.4, 0, 1), 4);
      ctx.restore();
    }

    // bottom bar: arsenal
    ctx.textAlign = "left";
    ctx.font = `bold 12px ${FONT}`;
    let ax = 18;
    (Object.keys(this.arsenal) as Kind[]).forEach((k) => {
      const a = this.arsenal[k];
      if (a.count <= 0) return;
      ctx.fillStyle = KINDS[k].color;
      ctx.beginPath();
      ctx.arc(ax + 5, 944, 5, 0, 6.283);
      ctx.fill();
      ctx.fillStyle = "#cbbfff";
      const txt = `×${a.count}`;
      ctx.fillText(txt, ax + 13, 948);
      ax += 18 + ctx.measureText(txt).width + 8;
    });
    if (this.net > 0) {
      ctx.fillStyle = "#6ff";
      ctx.fillText(`🕸 ${this.net}`, ax + 4, 948);
    }

    // warp button
    const wx = 486;
    const wy = 922;
    const active = this.timeScale < 0.8;
    ctx.fillStyle = active ? "rgba(90,130,255,0.5)" : "rgba(255,255,255,0.08)";
    ctx.beginPath();
    ctx.arc(wx, wy, 26, 0, 6.283);
    ctx.fill();
    ctx.strokeStyle = "rgba(255,255,255,0.15)";
    ctx.lineWidth = 4;
    ctx.stroke();
    ctx.strokeStyle = this.warp > 99 ? "#ffd84d" : "#5b8cff";
    ctx.beginPath();
    ctx.arc(wx, wy, 26, -Math.PI / 2, -Math.PI / 2 + (this.warp / this.maxWarp()) * Math.PI * 2);
    ctx.stroke();
    ctx.fillStyle = "#fff";
    ctx.font = "20px sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("⏳", wx, wy + 1);

    // ready hint
    if (this.phase === "ready" && this.screen === "playing" && this.time < 1e9) {
      const k = this.readyT / this.readyMax;
      ctx.globalAlpha = 0.5 + 0.3 * Math.sin(this.time * 8);
      ctx.fillStyle = "#fff";
      ctx.font = `bold 13px ${FONT}`;
      ctx.fillText("ЗАЛП…", this.px, PADDLE_Y - 62 - (1 - k) * 4);
      ctx.globalAlpha = 1;
    }

    if (this.phase === "flying" && this.screen === "playing" && this.balls.length > 0 && this.balls.length <= Math.max(1, Math.ceil(this.volleySize * 0.5))) {
      ctx.globalAlpha = 0.45 + 0.25 * Math.sin(this.time * 6);
      ctx.fillStyle = "#9bd8ff";
      ctx.font = `bold 12px ${FONT}`;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText("ПРОБЕЛ / КЛИК — ВЕРНУТЬ ШАРЫ", W / 2 - 20, 900);
      ctx.globalAlpha = 1;
    }

    // banner
    if (this.bannerT > 0) {
      const t = 2 - this.bannerT;
      const a = clamp(Math.min(t * 5, this.bannerT * 2.5), 0, 1);
      const sc = 1 + Math.max(0, 0.3 - t) * 2;
      ctx.save();
      ctx.globalAlpha = a;
      ctx.translate(W / 2, 400);
      ctx.scale(sc, sc);
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.font = `bold 40px ${FONT}`;
      ctx.lineWidth = 6;
      ctx.strokeStyle = "rgba(10,0,30,0.85)";
      ctx.strokeText(this.bannerText, 0, 0);
      ctx.fillStyle = this.bannerColor;
      ctx.fillText(this.bannerText, 0, 0);
      if (this.bannerSub) {
        ctx.font = `bold 16px ${FONT}`;
        ctx.lineWidth = 4;
        ctx.strokeText(this.bannerSub, 0, 36);
        ctx.fillStyle = "#fff";
        ctx.fillText(this.bannerSub, 0, 36);
      }
      ctx.restore();
    }
  }
}
