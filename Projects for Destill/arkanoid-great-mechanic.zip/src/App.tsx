import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { MouseEvent } from "react";
import { Game } from "./game/engine";
import type { Loadout, Screen, Summary } from "./game/engine";
import { KINDS, addScore, getName, loadMute, loadScores, renameScore, saveMute, setName as persistName } from "./game/data";
import type { Card, HighScore } from "./game/data";

const ASPECT = 540 / 960;

function useFrameSize() {
  const [size, setSize] = useState({ w: 540, h: 960, vw: 1000 });
  useEffect(() => {
    const calc = () => {
      const vw = window.innerWidth;
      const vh = window.visualViewport?.height ?? window.innerHeight;
      const w = Math.floor(Math.min(vw, vh * ASPECT));
      setSize({ w, h: Math.floor(w / ASPECT), vw });
    };
    calc();
    window.addEventListener("resize", calc);
    window.visualViewport?.addEventListener("resize", calc);
    return () => {
      window.removeEventListener("resize", calc);
      window.visualViewport?.removeEventListener("resize", calc);
    };
  }, []);
  return size;
}

function Btn(props: { onClick: () => void; className?: string; children: React.ReactNode }) {
  return (
    <button
      tabIndex={-1}
      className={`btn ${props.className ?? ""}`}
      onClick={(e: MouseEvent<HTMLButtonElement>) => {
        e.currentTarget.blur();
        props.onClick();
      }}
    >
      {props.children}
    </button>
  );
}

function ScoreTable({ rows, me }: { rows: HighScore[]; me?: number }) {
  return (
    <div className="table">
      <h4>🏆 ТАБЛИЦА РЕКОРДОВ</h4>
      {rows.length === 0 && <div className="empty">Пока пусто — стань первым!</div>}
      {rows.map((r, i) => (
        <div key={r.id} className={`trow ${r.id === me ? "me" : ""}`}>
          <span className="n">{i + 1}</span>
          <span className="nm">{r.name}</span>
          <span className="sc">{r.score.toLocaleString("ru-RU")}</span>
          <span className="dp">⬇ {r.depth}</span>
        </div>
      ))}
    </div>
  );
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<Game | null>(null);
  const { w, h, vw } = useFrameSize();
  const [screen, setScreen] = useState<Screen>("menu");
  const [cards, setCards] = useState<Card[]>([]);
  const [summary, setSummary] = useState<Summary | null>(null);
  const [table, setTable] = useState<HighScore[]>(() => loadScores());
  const [entryId, setEntryId] = useState(-1);
  const [isBest, setIsBest] = useState(false);
  const [name, setNameState] = useState(getName());
  const [muted, setMuted] = useState(loadMute());
  const [loadout, setLoadout] = useState<Loadout | null>(null);
  const mutedRef = useRef(muted);
  mutedRef.current = muted;

  useEffect(() => {
    const canvas = canvasRef.current!;
    const game = new Game(canvas, {
      onScreen: (s) => setScreen(s),
      onCards: (c) => setCards(c),
      onGameOver: (r) => {
        setSummary(r);
        const prev = loadScores();
        const best = prev.length === 0 || r.score > prev[0].score;
        setIsBest(best && r.score > 0);
        if (r.score > 0) {
          const res = addScore({ name: getName(), score: r.score, depth: r.depth, level: r.level });
          setTable(res.table);
          setEntryId(res.id);
        } else {
          setEntryId(-1);
          setTable(prev);
        }
        setNameState(getName());
      },
    });
    game.setMuted(mutedRef.current);
    gameRef.current = game;
    return () => {
      game.destroy();
      gameRef.current = null;
    };
  }, []);

  useEffect(() => {
    const g = gameRef.current;
    if (!g) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    g.setSize(w, dpr);
  }, [w]);

  useEffect(() => {
    if (screen === "menu") setTable(loadScores());
    if (screen === "paused") setLoadout(gameRef.current?.getLoadout() ?? null);
  }, [screen]);

  const toggleMute = useCallback(() => {
    setMuted((m) => {
      const n = !m;
      saveMute(n);
      gameRef.current?.setMuted(n);
      return n;
    });
  }, []);

  // keyboard "M" in the engine toggles audio directly; keep UI in sync
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.code === "KeyM" && (e.target as HTMLElement).tagName !== "INPUT") {
        setTimeout(() => {
          const g = gameRef.current;
          if (g) {
            setMuted(g.sfx.muted);
            saveMute(g.sfx.muted);
          }
        }, 0);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const start = () => gameRef.current?.start();
  const showSide = (vw - w) / 2 > 260;
  const best = table[0]?.score ?? 0;

  const loadoutBalls = useMemo(() => loadout?.balls ?? [], [loadout]);

  return (
    <div className="stage">
      {showSide && (
        <div className="side" style={{ textAlign: "right" }}>
          <h3>УПРАВЛЕНИЕ</h3>
          <div className="row">
            <kbd>←</kbd>
            <kbd>→</kbd> / <kbd>A</kbd>
            <kbd>D</kbd> двигать
          </div>
          <div className="row">
            <kbd>Мышь</kbd> водить платформу
          </div>
          <div className="row">
            <kbd>Space</kbd> залп / вернуть шары
          </div>
          <div className="row">
            <kbd>Shift</kbd> замедление времени
          </div>
          <div className="row">
            <kbd>P</kbd> пауза <kbd>R</kbd> рестарт <kbd>M</kbd> звук
          </div>
          <div className="row" style={{ marginTop: "1.2em", color: "#8f86c9" }}>
            Касание: веди пальцем — платформа едет следом. Кнопка ⏳ — замедление.
          </div>
        </div>
      )}

      <div className="frame" style={{ width: w, height: h, fontSize: (w / 540) * 16 }}>
        <canvas ref={canvasRef} />

        {screen === "menu" && (
          <div className="ov">
            <h1 className="logo">
              NEON
              <br />
              PIT
            </h1>
            <p className="tagline">Ломай. Сливай шары. Спускайся глубже.</p>
            <Btn className="primary" onClick={start}>
              ИГРАТЬ
            </Btn>
            <div className="hint">Space / Enter / тап — начать</div>
            <ScoreTable rows={table.slice(0, 5)} />
            <div className="tips">
              <div>
                <b>⚗ Слияния:</b> 🔥+💣 = ☀️ Нова, ❄️+⚡ = 🌩️ Шторм
              </div>
              <div>
                <b>✨ Идеальный удар</b> центром платформы заряжает шар ×2
              </div>
              <div>
                <b>💎 Лови кристаллы</b> платформой — это опыт и новые шары
              </div>
              <div>
                <b>⏳ Замедление</b> копится от комбо. Босс — каждые 14 рядов
              </div>
            </div>
            <div className="btnrow">
              <Btn className="small" onClick={toggleMute}>
                {muted ? "🔇 Звук выкл" : "🔊 Звук вкл"}
              </Btn>
            </div>
          </div>
        )}

        {screen === "paused" && (
          <div className="ov dim">
            <h2 className="h2">ПАУЗА</h2>
            <div className="btnrow" style={{ marginTop: 0 }}>
              <Btn className="primary" onClick={() => gameRef.current?.resume()}>
                ПРОДОЛЖИТЬ
              </Btn>
            </div>
            <div className="btnrow">
              <Btn onClick={start}>↻ Заново (R)</Btn>
              <Btn onClick={() => gameRef.current?.toMenu()}>Меню</Btn>
              <Btn onClick={toggleMute}>{muted ? "🔇" : "🔊"}</Btn>
            </div>
            <div className="sectionlabel">АРСЕНАЛ</div>
            <div className="loadout">
              {loadoutBalls.map((b) => (
                <span key={b.kind} className="chip" style={{ borderColor: KINDS[b.kind].color }}>
                  {KINDS[b.kind].icon} {KINDS[b.kind].name} ×{b.count} · ур.{b.level}
                </span>
              ))}
            </div>
            {loadout && loadout.passives.length > 0 && (
              <>
                <div className="sectionlabel">УЛУЧШЕНИЯ</div>
                <div className="loadout">
                  {loadout.passives.map((p) => (
                    <span key={p.id} className="chip">
                      {p.icon} {p.name} {p.lvl}
                    </span>
                  ))}
                </div>
              </>
            )}
            <div className="hint">Esc / P — продолжить</div>
          </div>
        )}

        {screen === "levelup" && (
          <div className="ov dim">
            <h2 className="h2" style={{ color: "#58ffe2" }}>
              НОВЫЙ УРОВЕНЬ!
            </h2>
            <div className="hint" style={{ marginTop: 0 }}>
              Выбери мутацию
            </div>
            <div className="cards">
              {cards.map((c, i) => (
                <button
                  key={c.id}
                  tabIndex={-1}
                  className={`card ${c.type === "fusion" ? "fusion" : ""}`}
                  style={{ ["--c" as string]: c.color }}
                  onClick={(e) => {
                    e.currentTarget.blur();
                    gameRef.current?.pick(c.id);
                  }}
                >
                  <span className="key">{i + 1}</span>
                  <span className="ic">{c.icon}</span>
                  <span>
                    <div className="tag">{c.tag}</div>
                    <div className="tt">{c.title}</div>
                    <div className="ds">{c.desc}</div>
                    {c.sub && <div className="sb">{c.sub}</div>}
                  </span>
                </button>
              ))}
            </div>
          </div>
        )}

        {screen === "gameover" && summary && (
          <div className="ov dim">
            <h2 className="h2" style={{ color: "#ff4d77" }}>
              ПИТ ПОГЛОТИЛ ТЕБЯ
            </h2>
            {isBest && <div className="newbest">★ НОВЫЙ РЕКОРД ★</div>}
            <div className="bigscore">{summary.score.toLocaleString("ru-RU")}</div>
            <div className="hint" style={{ marginTop: "0.3em" }}>
              рекорд: {Math.max(best, summary.score).toLocaleString("ru-RU")}
            </div>
            <div className="stats">
              <div>
                <b>{summary.depth}</b>глубина
              </div>
              <div>
                <b>{summary.level}</b>уровень
              </div>
              <div>
                <b>{summary.kills}</b>кирпичей
              </div>
              <div>
                <b>×{summary.maxCombo}</b>комбо
              </div>
            </div>
            {entryId !== -1 && (
              <input
                className="nameinput"
                value={name}
                maxLength={12}
                placeholder="Твоё имя"
                onChange={(e) => {
                  const v = e.target.value;
                  setNameState(v);
                  const n = v.trim() || "ИГРОК";
                  persistName(n);
                  setTable(renameScore(entryId, n));
                }}
                onKeyDown={(e) => {
                  if (e.key === "Enter") (e.target as HTMLInputElement).blur();
                }}
              />
            )}
            <ScoreTable rows={table.slice(0, 5)} me={entryId} />
            <div className="btnrow">
              <Btn className="primary" onClick={start}>
                ЕЩЁ РАЗ
              </Btn>
            </div>
            <div className="btnrow" style={{ marginTop: "0.6em" }}>
              <Btn className="small" onClick={() => gameRef.current?.toMenu()}>
                В меню
              </Btn>
            </div>
            <div className="hint">Space / Enter / R — мгновенный рестарт</div>
          </div>
        )}
      </div>

      {showSide && (
        <div className="side">
          <h3>МЕХАНИКИ</h3>
          <div className="row">🔥 горение · ❄️ хрупкость · ⚡ цепь</div>
          <div className="row">💣 взрыв · 🧪 яд · 🌀 пробитие</div>
          <div className="row" style={{ color: "#ffd84d" }}>
            ⚗ Прокачай два шара до ур. 2 — и получишь слияние: ☀️ Нова, 🌩️ Шторм, 🦠 Чума, 🚀 Рейлган.
          </div>
          <div className="row">Красные «TNT» цепляют соседей. Кристаллы дают много опыта.</div>
          <div className="row" style={{ color: "#8f86c9" }}>
            Стена падает быстрее, когда поле пустеет, и медленнее — если ты в опасности.
          </div>
        </div>
      )}
    </div>
  );
}
